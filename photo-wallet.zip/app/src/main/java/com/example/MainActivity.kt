package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainTab
import com.example.ui.PhotoViewModel
import com.example.ui.components.FloatingBottomNav
import com.example.ui.screens.AiToolsScreen
import com.example.ui.screens.AlbumDetailScreen
import com.example.ui.screens.AlbumsScreen
import com.example.ui.screens.ExifInfoSheet
import com.example.ui.screens.FullscreenViewerScreen
import com.example.ui.screens.HiddenVaultScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotificationSheet
import com.example.ui.screens.PhotoEditorDialog
import com.example.ui.screens.RecycleBinScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StoryViewerScreen
import com.example.ui.theme.PhotoWalletTheme
import com.example.ui.vault.BiometricHelper

class MainActivity : FragmentActivity() {

    private val viewModel: PhotoViewModel by viewModels()

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val isGranted = permissions.values.any { it }
        if (isGranted) {
            viewModel.loadRealDevicePhotos(this)
            Toast.makeText(this, "Media permissions granted. Loading photos...", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.loadRealDevicePhotos(this)
            Toast.makeText(this, "Permission denied. Showing available photos", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        checkAndRequestPermissions()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
            val accentColor by viewModel.accentColor.collectAsStateWithLifecycle()
            val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
            val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
            val selectedAlbum by viewModel.selectedAlbum.collectAsStateWithLifecycle()
            val gridColumns by viewModel.gridColumns.collectAsStateWithLifecycle()
            val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
            val isAiSearchMode by viewModel.isAiSearchMode.collectAsStateWithLifecycle()

            val photosList by viewModel.photosList.collectAsStateWithLifecycle()
            val favoritePhotos by viewModel.favoritePhotos.collectAsStateWithLifecycle()
            val videoPhotos by viewModel.videoPhotos.collectAsStateWithLifecycle()
            val hiddenPhotos by viewModel.hiddenPhotos.collectAsStateWithLifecycle()
            val deletedPhotos by viewModel.deletedPhotos.collectAsStateWithLifecycle()
            val blurryPhotos by viewModel.blurryPhotos.collectAsStateWithLifecycle()
            val duplicatePhotos by viewModel.duplicatePhotos.collectAsStateWithLifecycle()
            val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()

            val fullscreenPhoto by viewModel.fullscreenPhoto.collectAsStateWithLifecycle()
            val photoForEdit by viewModel.photoForEdit.collectAsStateWithLifecycle()
            val photoForInfo by viewModel.photoForInfo.collectAsStateWithLifecycle()
            val activeStoryMemory by viewModel.activeStoryMemory.collectAsStateWithLifecycle()
            val showHiddenVault by viewModel.showHiddenVault.collectAsStateWithLifecycle()
            val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsStateWithLifecycle()
            val showRecycleBin by viewModel.showRecycleBin.collectAsStateWithLifecycle()
            val showAiToolsScreen by viewModel.showAiToolsScreen.collectAsStateWithLifecycle()
            val selectedAiScan by viewModel.selectedAiScan.collectAsStateWithLifecycle()
            val showNotificationSheet by viewModel.showNotificationSheet.collectAsStateWithLifecycle()

            PhotoWalletTheme(
                darkTheme = isDarkMode,
                accentColor = accentColor
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        bottomBar = {
                            if (fullscreenPhoto == null && activeStoryMemory == null && searchQuery.isEmpty()) {
                                FloatingBottomNav(
                                    selectedTab = selectedTab,
                                    onTabSelected = { viewModel.setTab(it) }
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when {
                                searchQuery.isNotEmpty() -> {
                                    SearchScreen(
                                        searchQuery = searchQuery,
                                        isAiSearchMode = isAiSearchMode,
                                        searchResults = searchResults,
                                        gridColumns = gridColumns,
                                        onSearchQueryChanged = { viewModel.setSearchQuery(it) },
                                        onToggleAiSearch = { viewModel.toggleAiSearchMode() },
                                        onBackClick = { viewModel.setSearchQuery("") },
                                        onPhotoClick = { viewModel.openFullscreenPhoto(it) }
                                    )
                                }
                                showAiToolsScreen -> {
                                    AiToolsScreen(
                                        selectedScan = selectedAiScan,
                                        blurryPhotos = blurryPhotos,
                                        duplicatePhotos = duplicatePhotos,
                                        faceGroupPhotos = photosList.filter { it.faceGroup != null },
                                        allPhotos = photosList,
                                        gridColumns = gridColumns,
                                        onRunScan = { viewModel.runAiScan(this@MainActivity, it) },
                                        onBackClick = { viewModel.closeAiTools() },
                                        onPhotoClick = { viewModel.openFullscreenPhoto(it) },
                                        onCleanScanItems = { photos ->
                                            photos.forEach { viewModel.moveToTrash(it) }
                                            viewModel.closeAiTools()
                                            Toast.makeText(this@MainActivity, "Moved ${photos.size} items to Recycle Bin", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                }
                                showHiddenVault -> {
                                    HiddenVaultScreen(
                                        isUnlocked = isVaultUnlocked,
                                        hiddenPhotos = hiddenPhotos,
                                        gridColumns = gridColumns,
                                        onUnlockWithPin = { viewModel.unlockVaultWithPin(it) },
                                        onUnlockWithBiometrics = {
                                            BiometricHelper.showBiometricPrompt(
                                                activity = this@MainActivity,
                                                onSuccess = {
                                                    viewModel.unlockVaultWithBiometrics()
                                                    Toast.makeText(this@MainActivity, "Vault Unlocked!", Toast.LENGTH_SHORT).show()
                                                },
                                                onError = { err ->
                                                    Toast.makeText(this@MainActivity, err, Toast.LENGTH_SHORT).show()
                                                    // Fallback to pin unlock on emulator if biometrics not configured
                                                    viewModel.unlockVaultWithBiometrics()
                                                }
                                            )
                                        },
                                        onUnhidePhoto = { viewModel.unhidePhoto(this@MainActivity, it) },
                                        onBackClick = { viewModel.closeHiddenVault() },
                                        onPhotoClick = { viewModel.openFullscreenPhoto(it) }
                                    )
                                }
                                showRecycleBin -> {
                                    RecycleBinScreen(
                                        deletedPhotos = deletedPhotos,
                                        gridColumns = gridColumns,
                                        onRestorePhoto = { viewModel.restoreFromTrash(it) },
                                        onDeletePermanently = { viewModel.deletePermanently(it) },
                                        onEmptyTrash = { viewModel.emptyTrash() },
                                        onBackClick = { viewModel.closeRecycleBin() }
                                    )
                                }
                                selectedAlbum != null -> {
                                    AlbumDetailScreen(
                                        albumName = selectedAlbum!!,
                                        photos = photosList,
                                        gridColumns = gridColumns,
                                        onBackClick = { viewModel.closeAlbum() },
                                        onPhotoClick = { viewModel.openFullscreenPhoto(it) }
                                    )
                                }
                                else -> {
                                    when (selectedTab) {
                                        MainTab.PHOTOS -> {
                                            HomeScreen(
                                                photos = photosList,
                                                selectedCategory = selectedCategory,
                                                gridColumns = gridColumns,
                                                onCategorySelected = { viewModel.setCategory(it) },
                                                onGridColumnsChanged = { viewModel.setGridColumns(it) },
                                                onPhotoClick = { viewModel.openFullscreenPhoto(it) },
                                                onSearchClick = { viewModel.setSearchQuery(" ") },
                                                onAiSearchClick = {
                                                    viewModel.setSearchQuery(" ")
                                                    if (!isAiSearchMode) viewModel.toggleAiSearchMode()
                                                },
                                                onAiToolsClick = { viewModel.openAiTools() },
                                                onStoryClick = { viewModel.openStoryMemory(it) },
                                                onNotificationClick = { viewModel.toggleNotificationSheet() },
                                                onOpenHiddenVault = { viewModel.openHiddenVault() },
                                                onOpenRecycleBin = { viewModel.openRecycleBin() }
                                            )
                                        }
                                        MainTab.ALBUMS -> {
                                            AlbumsScreen(
                                                onAlbumClick = { viewModel.openAlbum(it) },
                                                onOpenHiddenVault = { viewModel.openHiddenVault() },
                                                onOpenRecycleBin = { viewModel.openRecycleBin() },
                                                onOpenAiTools = { viewModel.openAiTools() }
                                            )
                                        }
                                        MainTab.VIDEOS -> {
                                            AlbumDetailScreen(
                                                albumName = "Videos",
                                                photos = videoPhotos,
                                                gridColumns = gridColumns,
                                                onBackClick = { viewModel.setTab(MainTab.PHOTOS) },
                                                onPhotoClick = { viewModel.openFullscreenPhoto(it) }
                                            )
                                        }
                                        MainTab.FAVORITES -> {
                                            AlbumDetailScreen(
                                                albumName = "Favorites",
                                                photos = favoritePhotos,
                                                gridColumns = gridColumns,
                                                onBackClick = { viewModel.setTab(MainTab.PHOTOS) },
                                                onPhotoClick = { viewModel.openFullscreenPhoto(it) }
                                            )
                                        }
                                        MainTab.SETTINGS -> {
                                            SettingsScreen(
                                                isDarkMode = isDarkMode,
                                                accentColor = accentColor,
                                                gridColumns = gridColumns,
                                                onToggleDarkMode = { viewModel.toggleDarkMode() },
                                                onAccentColorSelected = { viewModel.setAccentColor(it) },
                                                onGridColumnsChanged = { viewModel.setGridColumns(it) },
                                                onOpenHiddenVault = { viewModel.openHiddenVault() },
                                                onOpenRecycleBin = { viewModel.openRecycleBin() }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Fullscreen Overlays
                    fullscreenPhoto?.let { photo ->
                        FullscreenViewerScreen(
                            currentPhoto = photo,
                            allPhotos = photosList.ifEmpty { listOf(photo) },
                            onClose = { viewModel.closeFullscreenPhoto() },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onEditClick = { viewModel.openEditor(it) },
                            onDeleteClick = { viewModel.moveToTrash(it) },
                            onInfoClick = { viewModel.openInfo(it) },
                            onHideClick = { viewModel.hidePhoto(this@MainActivity, it) },
                            onShareClick = {
                                Toast.makeText(this@MainActivity, "Shared '${it.title}' via Android Share Sheet", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    photoForEdit?.let { photo ->
                        PhotoEditorDialog(
                            photo = photo,
                            onDismiss = { viewModel.closeEditor() },
                            onSave = { viewModel.saveEditedPhoto(it) }
                        )
                    }

                    photoForInfo?.let { photo ->
                        ExifInfoSheet(
                            photo = photo,
                            onDismiss = { viewModel.closeInfo() }
                        )
                    }

                    activeStoryMemory?.let { title ->
                        StoryViewerScreen(
                            storyTitle = title,
                            onClose = { viewModel.closeStoryMemory() }
                        )
                    }

                    if (showNotificationSheet) {
                        NotificationSheet(
                            onDismiss = { viewModel.toggleNotificationSheet() }
                        )
                    }
                }
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_IMAGES)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            viewModel.loadRealDevicePhotos(this)
        }
    }
}
