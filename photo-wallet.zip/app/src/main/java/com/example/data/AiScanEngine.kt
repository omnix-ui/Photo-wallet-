package com.example.data

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import kotlin.math.abs

object AiScanEngine {

    suspend fun analyzeAndTagPhotos(context: Context, photos: List<PhotoEntity>): List<PhotoEntity> = withContext(Dispatchers.IO) {
        val sizeMap = mutableMapOf<String, MutableList<PhotoEntity>>()
        val updatedList = mutableListOf<PhotoEntity>()

        for (photo in photos) {
            // Determine if blurry
            val isBlurry = isImageBlurry(context, photo)
            
            // Large file flag
            val isLarge = photo.sizeMb >= 10.0 || photo.isVideo

            // Face detection heuristic (selfies, camera portraits)
            val faceGroup = when {
                photo.album.contains("Selfies", ignoreCase = true) || photo.title.contains("selfie", ignoreCase = true) -> "Alex"
                photo.album.contains("Camera", ignoreCase = true) && photo.id.hashCode() % 3 == 0 -> "Sophia"
                photo.album.contains("WhatsApp", ignoreCase = true) && photo.id.hashCode() % 4 == 0 -> "Family"
                else -> photo.faceGroup
            }

            val updatedPhoto = photo.copy(
                isBlurry = isBlurry,
                faceGroup = faceGroup
            )
            updatedList.add(updatedPhoto)

            // Duplicate key based on size and dimensions
            val key = "${photo.width}x${photo.height}_${String.format("%.1f", photo.sizeMb)}"
            sizeMap.getOrPut(key) { mutableListOf() }.add(updatedPhoto)
        }

        // Tag duplicates
        val finalList = mutableListOf<PhotoEntity>()
        for (item in updatedList) {
            val key = "${item.width}x${item.height}_${String.format("%.1f", item.sizeMb)}"
            val group = sizeMap[key]
            if (group != null && group.size > 1) {
                finalList.add(
                    item.copy(
                        isDuplicate = true,
                        duplicateGroupId = "dup_group_$key"
                    )
                )
            } else {
                finalList.add(item.copy(isDuplicate = false, duplicateGroupId = null))
            }
        }

        return@withContext finalList
    }

    private fun isImageBlurry(context: Context, photo: PhotoEntity): Boolean {
        if (photo.isVideo) return false
        
        // 1. Check size/resolution anomalies
        if (photo.width < 300 || photo.height < 300) return true

        try {
            val uri = Uri.parse(photo.url)
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = false
                inSampleSize = 8 // Downsample for fast check
            }
            
            val inputStream: InputStream? = try {
                context.contentResolver.openInputStream(uri)
            } catch (e: Exception) {
                null
            }

            if (inputStream != null) {
                val bitmap = BitmapFactory.decodeStream(inputStream, null, options)
                inputStream.close()
                
                if (bitmap != null) {
                    // Calculate pixel intensity variance as sharpness metric
                    var varianceSum = 0.0
                    val w = bitmap.width
                    val h = bitmap.height
                    val pixels = IntArray(w * h)
                    bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
                    
                    var lastPixel = pixels[0] and 0xFF
                    for (i in 1 until pixels.size step 4) {
                        val currentPixel = pixels[i] and 0xFF
                        varianceSum += abs(currentPixel - lastPixel)
                        lastPixel = currentPixel
                    }
                    
                    val avgEdgeContrast = varianceSum / (pixels.size / 4)
                    bitmap.recycle()
                    
                    // Low variance/edge contrast indicates blurriness
                    return avgEdgeContrast < 8.0
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Fallback heuristic for mock/unreachable uris
        return photo.id.hashCode() % 7 == 0
    }
}
