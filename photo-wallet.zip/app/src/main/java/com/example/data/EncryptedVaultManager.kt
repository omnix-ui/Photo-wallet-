package com.example.data

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object EncryptedVaultManager {

    private const val KEY_ALIAS = "PhotoWalletVaultKey"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_LENGTH = 128

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val keyGenSpec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            keyGenerator.init(keyGenSpec)
            return keyGenerator.generateKey()
        }
        return (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    fun encryptPhotoToPrivateVault(context: Context, uriString: String, photoId: String): String {
        val vaultDir = File(context.filesDir, "vault").apply { if (!exists()) mkdirs() }
        val encryptedFile = File(vaultDir, "enc_$photoId.bin")

        try {
            val uri = Uri.parse(uriString)
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: FileInputStream(File(uriString))

            val bytes = inputStream.readBytes()
            inputStream.close()

            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
            val iv = cipher.iv
            val encryptedBytes = cipher.doFinal(bytes)

            FileOutputStream(encryptedFile).use { fos ->
                fos.write(iv.size)
                fos.write(iv)
                fos.write(encryptedBytes)
            }
            return encryptedFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback if encryption fails or mock file
            return uriString
        }
    }

    fun getDecryptedPhotoFile(context: Context, photoId: String, encryptedPath: String): File? {
        val encryptedFile = File(encryptedPath)
        if (!encryptedFile.exists()) return null

        try {
            val fis = FileInputStream(encryptedFile)
            val ivSize = fis.read()
            if (ivSize <= 0) return null

            val iv = ByteArray(ivSize)
            fis.read(iv)
            val encryptedBytes = fis.readBytes()
            fis.close()

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(GCM_TAG_LENGTH, iv)
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)

            val decryptedBytes = cipher.doFinal(encryptedBytes)

            val cacheFile = File(context.cacheDir, "dec_$photoId.jpg")
            FileOutputStream(cacheFile).use { fos ->
                fos.write(decryptedBytes)
            }
            return cacheFile
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun deleteEncryptedFile(encryptedPath: String) {
        try {
            val file = File(encryptedPath)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
