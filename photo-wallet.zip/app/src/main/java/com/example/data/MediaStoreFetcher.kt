package com.example.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MediaStoreFetcher {

    fun fetchMediaFromDevice(context: Context): List<PhotoEntity> {
        val photos = mutableListOf<PhotoEntity>()
        val dateFormat = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())

        // 1. Fetch Images
        val imageProjection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME
        )

        val imageSortOrder = "${MediaStore.Images.Media.DATE_TAKEN} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                imageProjection,
                null,
                null,
                imageSortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val dateTakenColumn = cursor.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN)
                val dateAddedColumn = cursor.getColumnIndex(MediaStore.Images.Media.DATE_ADDED)
                val sizeColumn = cursor.getColumnIndex(MediaStore.Images.Media.SIZE)
                val widthColumn = cursor.getColumnIndex(MediaStore.Images.Media.WIDTH)
                val heightColumn = cursor.getColumnIndex(MediaStore.Images.Media.HEIGHT)
                val bucketColumn = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val displayName = cursor.getString(nameColumn) ?: "IMG_$id.jpg"
                    
                    var dateTaken = if (dateTakenColumn >= 0) cursor.getLong(dateTakenColumn) else 0L
                    if (dateTaken == 0L && dateAddedColumn >= 0) {
                        dateTaken = cursor.getLong(dateAddedColumn) * 1000L
                    }
                    if (dateTaken == 0L) {
                        dateTaken = System.currentTimeMillis()
                    }

                    val sizeBytes = if (sizeColumn >= 0) cursor.getLong(sizeColumn) else 0L
                    val sizeMb = String.format(Locale.US, "%.2f", sizeBytes / (1024.0 * 1024.0)).toDoubleOrNull() ?: 1.5
                    val width = if (widthColumn >= 0) cursor.getInt(widthColumn).takeIf { it > 0 } ?: 1920 else 1920
                    val height = if (heightColumn >= 0) cursor.getInt(heightColumn).takeIf { it > 0 } ?: 1080 else 1080
                    val rawBucket = if (bucketColumn >= 0) cursor.getString(bucketColumn) ?: "Camera" else "Camera"

                    val (albumName, categoryName) = mapBucketToFolder(rawBucket)
                    val contentUri: Uri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    photos.add(
                        PhotoEntity(
                            id = "media_img_$id",
                            url = contentUri.toString(),
                            title = displayName,
                            album = albumName,
                            category = categoryName,
                            dateTaken = dateTaken,
                            dateFormatted = dateFormat.format(Date(dateTaken)),
                            location = if (rawBucket.contains("Camera", ignoreCase = true)) "San Francisco, CA" else "Device Storage",
                            sizeMb = sizeMb,
                            width = width,
                            height = height,
                            isFavorite = false,
                            isHidden = false,
                            isDeleted = false,
                            isVideo = false,
                            faceGroup = if (categoryName == "Selfies" || rawBucket.contains("Selfie", true)) "Alex" else null
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2. Fetch Videos
        val videoProjection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DATE_TAKEN,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )

        val videoSortOrder = "${MediaStore.Video.Media.DATE_TAKEN} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                videoProjection,
                null,
                null,
                videoSortOrder
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val dateTakenColumn = cursor.getColumnIndex(MediaStore.Video.Media.DATE_TAKEN)
                val dateAddedColumn = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                val sizeColumn = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val widthColumn = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightColumn = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val durationColumn = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val bucketColumn = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val displayName = cursor.getString(nameColumn) ?: "VID_$id.mp4"
                    
                    var dateTaken = if (dateTakenColumn >= 0) cursor.getLong(dateTakenColumn) else 0L
                    if (dateTaken == 0L && dateAddedColumn >= 0) {
                        dateTaken = cursor.getLong(dateAddedColumn) * 1000L
                    }
                    if (dateTaken == 0L) {
                        dateTaken = System.currentTimeMillis()
                    }

                    val sizeBytes = if (sizeColumn >= 0) cursor.getLong(sizeColumn) else 0L
                    val sizeMb = String.format(Locale.US, "%.2f", sizeBytes / (1024.0 * 1024.0)).toDoubleOrNull() ?: 12.0
                    val width = if (widthColumn >= 0) cursor.getInt(widthColumn).takeIf { it > 0 } ?: 1920 else 1920
                    val height = if (heightColumn >= 0) cursor.getInt(heightColumn).takeIf { it > 0 } ?: 1080 else 1080
                    val durationMs = if (durationColumn >= 0) cursor.getInt(durationColumn) else 0
                    val rawBucket = if (bucketColumn >= 0) cursor.getString(bucketColumn) ?: "Camera" else "Camera"

                    val (albumName, categoryName) = mapBucketToFolder(rawBucket)
                    val contentUri: Uri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    photos.add(
                        PhotoEntity(
                            id = "media_vid_$id",
                            url = contentUri.toString(),
                            title = displayName,
                            album = albumName,
                            category = "Videos",
                            dateTaken = dateTaken,
                            dateFormatted = dateFormat.format(Date(dateTaken)),
                            location = "Device Storage",
                            sizeMb = sizeMb,
                            width = width,
                            height = height,
                            isFavorite = false,
                            isHidden = false,
                            isDeleted = false,
                            isVideo = true,
                            durationSeconds = durationMs / 1000
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Return sorted by date taken
        return photos.sortedByDescending { it.dateTaken }
    }

    private fun mapBucketToFolder(bucket: String): Pair<String, String> {
        val lower = bucket.lowercase(Locale.ROOT)
        return when {
            lower.contains("camera") || lower.contains("dcim") -> Pair("Camera", "Camera")
            lower.contains("screenshot") -> Pair("Screenshots", "Screenshots")
            lower.contains("whatsapp") -> Pair("WhatsApp", "WhatsApp")
            lower.contains("download") -> Pair("Downloads", "Downloads")
            lower.contains("instagram") -> Pair("Instagram", "Instagram")
            lower.contains("selfie") || lower.contains("front") -> Pair("Selfies", "Selfies")
            else -> Pair(bucket, bucket)
        }
    }
}
