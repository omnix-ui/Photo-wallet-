package com.example.data

import java.util.UUID

object MockDataInitializer {

    fun getInitialPhotos(): List<PhotoEntity> {
        val now = System.currentTimeMillis()
        val dayMs = 24 * 60 * 60 * 1000L

        // Curated Unsplash images with vivid topics (Landscapes, Architecture, People, Tech, Food, Night)
        val imageCatalog = listOf(
            Triple("https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&q=80", "Alpine Lake Reflection", "Camera"),
            Triple("https://images.unsplash.com/photo-1511765224389-37f0e77cf0eb?w=800&q=80", "Golden Hour Sunset Coast", "Camera"),
            Triple("https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800&q=80", "Cyberpunk Neon Tokyo Street", "Camera"),
            Triple("https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=800&q=80", "Cute Golden Retriever", "WhatsApp"),
            Triple("https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&q=80", "Portrait with Bokeh Light", "Selfies"),
            Triple("https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80", "Smiling Alex Portrait", "Selfies"),
            Triple("https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=800&q=80", "Sophia Beach Vibes", "Instagram"),
            Triple("https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&q=80", "Modern Developer Desk", "Screenshots"),
            Triple("https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&q=80", "Crypto Stock Dashboard", "Screenshots"),
            Triple("https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800&q=80", "Mid-Century Modern Sofa", "Downloads"),
            Triple("https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&q=80", "Artisan Wood-Fired Pizza", "Instagram"),
            Triple("https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=800&q=80", "Fresh Avocado Salad", "WhatsApp"),
            Triple("https://images.unsplash.com/photo-1502082553048-f009c37129b9?w=800&q=80", "Misty Forest Pine Trees", "Camera"),
            Triple("https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&q=80", "Foggy Valley Horizon", "Camera"),
            Triple("https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&q=80", "Solo Hiker Mountain Trail", "Camera"),
            Triple("https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80", "Cozy Bistro Cafe Interior", "Downloads"),
            Triple("https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&q=80", "Luxury Coastal Villa", "Downloads"),
            Triple("https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&q=80", "Emerald Bay Kayak Journey", "Camera"),
            Triple("https://images.unsplash.com/photo-1519741497674-611481863552?w=800&q=80", "Wedding Celebration Toast", "Camera"),
            Triple("https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=800&q=80", "Mom & Dad Anniversary", "WhatsApp"),
            Triple("https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&q=80", "Team Brainstorming Session", "Screenshots"),
            Triple("https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?w=800&q=80", "MacBook Code Editor UI", "Screenshots"),
            Triple("https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800&q=80", "Music Concert Laser Show", "Instagram"),
            Triple("https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=800&q=80", "Vintage Film Camera Lens", "Downloads")
        )

        val photos = mutableListOf<PhotoEntity>()

        imageCatalog.forEachIndexed { index, (url, title, album) ->
            val timestamp = now - (index * 1.5 * dayMs).toLong()
            val isFav = index % 4 == 0
            val isVid = index == 3 || index == 11 || index == 18
            val category = when (album) {
                "Screenshots" -> "Screenshots"
                "WhatsApp" -> "WhatsApp"
                "Selfies" -> "Selfies"
                "Downloads" -> "Downloads"
                "Instagram" -> "Instagram"
                else -> if (isVid) "Videos" else "Camera"
            }

            val faceTag = when (index % 5) {
                0 -> "Alex"
                1 -> "Sophia"
                2 -> "Mom"
                else -> null
            }

            val isBlurry = index == 7 || index == 14
            val isDuplicate = index == 2 || index == 12

            photos.add(
                PhotoEntity(
                    id = "photo_${index + 1}",
                    url = url,
                    title = title,
                    album = album,
                    category = category,
                    dateTaken = timestamp,
                    dateFormatted = formatDate(timestamp),
                    location = if (index % 2 == 0) "San Francisco, CA" else "Kyoto, Japan",
                    sizeMb = 2.4 + (index % 5),
                    width = 1920,
                    height = if (index % 3 == 0) 1440 else 1080,
                    isFavorite = isFav,
                    isHidden = false,
                    isDeleted = false,
                    isVideo = isVid,
                    durationSeconds = if (isVid) 15 + index * 4 else 0,
                    faceGroup = faceTag,
                    isBlurry = isBlurry,
                    isDuplicate = isDuplicate,
                    duplicateGroupId = if (isDuplicate) "dup_group_1" else null
                )
            )
        }

        // Add 2 initial Hidden vault photos
        photos.add(
            PhotoEntity(
                id = "vault_photo_1",
                url = "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=800&q=80",
                title = "Tax Receipt & Documents 2026",
                album = "Hidden",
                category = "Screenshots",
                dateTaken = now - 5 * dayMs,
                dateFormatted = formatDate(now - 5 * dayMs),
                isHidden = true,
                isFavorite = false
            )
        )
        photos.add(
            PhotoEntity(
                id = "vault_photo_2",
                url = "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&q=80",
                title = "Crypto Key Backup Note",
                album = "Hidden",
                category = "Screenshots",
                dateTaken = now - 10 * dayMs,
                dateFormatted = formatDate(now - 10 * dayMs),
                isHidden = true,
                isFavorite = false
            )
        )

        // Add 2 initial Recycle Bin photos
        photos.add(
            PhotoEntity(
                id = "trash_photo_1",
                url = "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?w=800&q=80",
                title = "Accidental Burst Shot 1",
                album = "Camera",
                category = "Camera",
                dateTaken = now - 2 * dayMs,
                dateFormatted = formatDate(now - 2 * dayMs),
                isDeleted = true,
                deletedTimestamp = now - (1 * dayMs)
            )
        )
        photos.add(
            PhotoEntity(
                id = "trash_photo_2",
                url = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&q=80",
                title = "Dark Underexposed Test",
                album = "Camera",
                category = "Camera",
                dateTaken = now - 4 * dayMs,
                dateFormatted = formatDate(now - 4 * dayMs),
                isDeleted = true,
                deletedTimestamp = now - (3 * dayMs)
            )
        )

        return photos
    }

    private fun formatDate(timeMs: Long): String {
        val sdf = java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.US)
        return sdf.format(java.util.Date(timeMs))
    }
}
