package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PhotoDao {

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 ORDER BY dateTaken DESC")
    fun getAllPhotos(): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 ORDER BY dateTaken DESC")
    suspend fun getAllPhotosSync(): List<PhotoEntity>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 AND category = :category ORDER BY dateTaken DESC")
    fun getPhotosByCategory(category: String): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 AND album = :album ORDER BY dateTaken DESC")
    fun getPhotosByAlbum(album: String): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 AND isFavorite = 1 ORDER BY dateTaken DESC")
    fun getFavoritePhotos(): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 AND isVideo = 1 ORDER BY dateTaken DESC")
    fun getVideoPhotos(): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 1 ORDER BY dateTaken DESC")
    fun getHiddenPhotos(): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 1 ORDER BY deletedTimestamp DESC")
    fun getDeletedPhotos(): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 AND isBlurry = 1")
    fun getBlurryPhotos(): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 AND isDuplicate = 1")
    fun getDuplicatePhotos(): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 AND faceGroup IS NOT NULL")
    fun getFaceGroupPhotos(): Flow<List<PhotoEntity>>

    @Query("SELECT * FROM photos WHERE isDeleted = 0 AND isHidden = 0 AND (title LIKE '%' || :query || '%' OR album LIKE '%' || :query || '%' OR location LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%') ORDER BY dateTaken DESC")
    fun searchPhotos(query: String): Flow<List<PhotoEntity>>

    @Query("SELECT COUNT(*) FROM photos WHERE isDeleted = 0 AND isHidden = 0")
    suspend fun getPhotoCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhotos(photos: List<PhotoEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPhoto(photo: PhotoEntity)

    @Update
    suspend fun updatePhoto(photo: PhotoEntity)

    @Query("UPDATE photos SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun setFavorite(id: String, isFavorite: Boolean)

    @Query("UPDATE photos SET isHidden = :isHidden WHERE id = :id")
    suspend fun setHidden(id: String, isHidden: Boolean)

    @Query("UPDATE photos SET isDeleted = 1, deletedTimestamp = :timestamp WHERE id = :id")
    suspend fun moveToTrash(id: String, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE photos SET isDeleted = 0, deletedTimestamp = 0 WHERE id = :id")
    suspend fun restoreFromTrash(id: String)

    @Query("DELETE FROM photos WHERE id = :id")
    suspend fun deletePermanently(id: String)

    @Query("DELETE FROM photos WHERE isDeleted = 1")
    suspend fun emptyTrash()
}
