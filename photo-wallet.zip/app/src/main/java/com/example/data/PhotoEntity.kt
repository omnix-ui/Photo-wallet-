package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "photos")
data class PhotoEntity(
    @PrimaryKey val id: String,
    val url: String,
    val title: String,
    val album: String, // e.g. "Camera", "Selfies", "Screenshots", "Downloads", "WhatsApp", "Instagram"
    val category: String, // Matches category chip e.g. "Camera", "Screenshots", "WhatsApp", "Videos", etc.
    val dateTaken: Long, // timestamp in ms
    val dateFormatted: String, // e.g. "May 14, 2026"
    val location: String = "San Francisco, CA",
    val sizeMb: Double = 3.2,
    val width: Int = 1920,
    val height: Int = 1080,
    val isFavorite: Boolean = false,
    val isHidden: Boolean = false,
    val isDeleted: Boolean = false,
    val deletedTimestamp: Long = 0L,
    val isVideo: Boolean = false,
    val durationSeconds: Int = 0,
    val faceGroup: String? = null, // e.g. "Alex", "Sophia", "Mom"
    val isBlurry: Boolean = false,
    val isDuplicate: Boolean = false,
    val duplicateGroupId: String? = null,
    val cameraModel: String = "Google Pixel 9 Pro",
    val iso: Int = 100,
    val aperture: String = "f/1.8",
    val shutterSpeed: String = "1/250s"
)
