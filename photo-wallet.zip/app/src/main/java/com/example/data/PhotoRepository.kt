package com.example.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class PhotoRepository(private val photoDao: PhotoDao) {

    val allPhotos: Flow<List<PhotoEntity>> = photoDao.getAllPhotos()
    val favoritePhotos: Flow<List<PhotoEntity>> = photoDao.getFavoritePhotos()
    val videoPhotos: Flow<List<PhotoEntity>> = photoDao.getVideoPhotos()
    val hiddenPhotos: Flow<List<PhotoEntity>> = photoDao.getHiddenPhotos()
    val deletedPhotos: Flow<List<PhotoEntity>> = photoDao.getDeletedPhotos()
    val blurryPhotos: Flow<List<PhotoEntity>> = photoDao.getBlurryPhotos()
    val duplicatePhotos: Flow<List<PhotoEntity>> = photoDao.getDuplicatePhotos()
    val faceGroupPhotos: Flow<List<PhotoEntity>> = photoDao.getFaceGroupPhotos()

    fun getPhotosByCategory(category: String): Flow<List<PhotoEntity>> {
        return if (category == "All Photos" || category == "All") {
            photoDao.getAllPhotos()
        } else if (category == "Favorites") {
            photoDao.getFavoritePhotos()
        } else if (category == "Videos") {
            photoDao.getVideoPhotos()
        } else {
            photoDao.getPhotosByCategory(category)
        }
    }

    fun getPhotosByAlbum(album: String): Flow<List<PhotoEntity>> {
        return photoDao.getPhotosByAlbum(album)
    }

    fun searchPhotos(query: String): Flow<List<PhotoEntity>> {
        return photoDao.searchPhotos(query)
    }

    suspend fun loadRealMediaFromDevice(context: Context) = withContext(Dispatchers.IO) {
        val realPhotos = MediaStoreFetcher.fetchMediaFromDevice(context)
        if (realPhotos.isNotEmpty()) {
            val analyzedPhotos = AiScanEngine.analyzeAndTagPhotos(context, realPhotos)
            photoDao.insertPhotos(analyzedPhotos)
        }
    }

    suspend fun runAiToolsScanOnLibrary(context: Context) = withContext(Dispatchers.IO) {
        val currentPhotos = photoDao.getAllPhotosSync()
        if (currentPhotos.isNotEmpty()) {
            val rescanned = AiScanEngine.analyzeAndTagPhotos(context, currentPhotos)
            photoDao.insertPhotos(rescanned)
        }
    }

    suspend fun hidePhotoToEncryptedVault(context: Context, photo: PhotoEntity) = withContext(Dispatchers.IO) {
        val encryptedPath = EncryptedVaultManager.encryptPhotoToPrivateVault(context, photo.url, photo.id)
        val updated = photo.copy(
            isHidden = true,
            url = encryptedPath
        )
        photoDao.updatePhoto(updated)
    }

    suspend fun unhidePhotoFromEncryptedVault(context: Context, photo: PhotoEntity) = withContext(Dispatchers.IO) {
        if (photo.url.contains("/vault/enc_")) {
            EncryptedVaultManager.deleteEncryptedFile(photo.url)
        }
        val updated = photo.copy(
            isHidden = false
        )
        photoDao.updatePhoto(updated)
    }

    suspend fun insertPhoto(photo: PhotoEntity) {
        photoDao.insertPhoto(photo)
    }

    suspend fun updatePhoto(photo: PhotoEntity) {
        photoDao.updatePhoto(photo)
    }

    suspend fun toggleFavorite(id: String, isFavorite: Boolean) {
        photoDao.setFavorite(id, isFavorite)
    }

    suspend fun toggleHide(id: String, isHidden: Boolean) {
        photoDao.setHidden(id, isHidden)
    }

    suspend fun moveToTrash(id: String) {
        photoDao.moveToTrash(id)
    }

    suspend fun restoreFromTrash(id: String) {
        photoDao.restoreFromTrash(id)
    }

    suspend fun deletePermanently(id: String) {
        photoDao.deletePermanently(id)
    }

    suspend fun emptyTrash() {
        photoDao.emptyTrash()
    }
}
