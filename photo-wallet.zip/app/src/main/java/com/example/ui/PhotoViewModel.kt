package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.PhotoEntity
import com.example.data.PhotoRepository
import com.example.ui.theme.AppAccentColor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab {
    PHOTOS, ALBUMS, VIDEOS, FAVORITES, SETTINGS
}

enum class AiScanType {
    SIMILAR, BLURRY, DUPLICATE, SCREENSHOT, LARGE_FILES, FACE_GROUPING, MEMORIES, AUTO_ALBUMS
}

class PhotoViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PhotoRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = PhotoRepository(database.photoDao())
        viewModelScope.launch {
            repository.checkAndPrepopulate()
        }
    }

    fun loadRealDevicePhotos(context: Context) {
        viewModelScope.launch {
            repository.loadRealMediaFromDevice(context)
        }
    }

    // Navigation & UI State
    private val _selectedTab = MutableStateFlow(MainTab.PHOTOS)
    val selectedTab: StateFlow<MainTab> = _selectedTab.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All Photos")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedAlbum = MutableStateFlow<String?>(null)
    val selectedAlbum: StateFlow<String?> = _selectedAlbum.asStateFlow()

    private val _gridColumns = MutableStateFlow(3)
    val gridColumns: StateFlow<Int> = _gridColumns.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _accentColor = MutableStateFlow(AppAccentColor.INDIGO)
    val accentColor: StateFlow<AppAccentColor> = _accentColor.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isAiSearchMode = MutableStateFlow(false)
    val isAiSearchMode: StateFlow<Boolean> = _isAiSearchMode.asStateFlow()

    // Fullscreen / Dialog States
    private val _fullscreenPhoto = MutableStateFlow<PhotoEntity?>(null)
    val fullscreenPhoto: StateFlow<PhotoEntity?> = _fullscreenPhoto.asStateFlow()

    private val _photoForEdit = MutableStateFlow<PhotoEntity?>(null)
    val photoForEdit: StateFlow<PhotoEntity?> = _photoForEdit.asStateFlow()

    private val _photoForInfo = MutableStateFlow<PhotoEntity?>(null)
    val photoForInfo: StateFlow<PhotoEntity?> = _photoForInfo.asStateFlow()

    private val _activeStoryMemory = MutableStateFlow<String?>(null)
    val activeStoryMemory: StateFlow<String?> = _activeStoryMemory.asStateFlow()

    private val _showHiddenVault = MutableStateFlow(false)
    val showHiddenVault: StateFlow<Boolean> = _showHiddenVault.asStateFlow()

    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    private val _showRecycleBin = MutableStateFlow(false)
    val showRecycleBin: StateFlow<Boolean> = _showRecycleBin.asStateFlow()

    private val _showAiToolsScreen = MutableStateFlow(false)
    val showAiToolsScreen: StateFlow<Boolean> = _showAiToolsScreen.asStateFlow()

    private val _selectedAiScan = MutableStateFlow<AiScanType?>(null)
    val selectedAiScan: StateFlow<AiScanType?> = _selectedAiScan.asStateFlow()

    private val _showNotificationSheet = MutableStateFlow(false)
    val showNotificationSheet: StateFlow<Boolean> = _showNotificationSheet.asStateFlow()

    // Photos Data Flows
    val photosList: StateFlow<List<PhotoEntity>> = combine(_selectedCategory, _selectedAlbum) { cat, album ->
        Pair(cat, album)
    }.flatMapLatest { (category, album) ->
        if (album != null) {
            repository.getPhotosByAlbum(album)
        } else {
            repository.getPhotosByCategory(category)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoritePhotos: StateFlow<List<PhotoEntity>> = repository.favoritePhotos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val videoPhotos: StateFlow<List<PhotoEntity>> = repository.videoPhotos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val hiddenPhotos: StateFlow<List<PhotoEntity>> = repository.hiddenPhotos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val deletedPhotos: StateFlow<List<PhotoEntity>> = repository.deletedPhotos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val blurryPhotos: StateFlow<List<PhotoEntity>> = repository.blurryPhotos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val duplicatePhotos: StateFlow<List<PhotoEntity>> = repository.duplicatePhotos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchResults: StateFlow<List<PhotoEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) repository.allPhotos
            else repository.searchPhotos(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Actions
    fun setTab(tab: MainTab) {
        _selectedTab.value = tab
        _selectedAlbum.value = null
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
        _selectedAlbum.value = null
    }

    fun openAlbum(albumName: String) {
        _selectedAlbum.value = albumName
    }

    fun closeAlbum() {
        _selectedAlbum.value = null
    }

    fun setGridColumns(cols: Int) {
        _gridColumns.value = cols
    }

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setAccentColor(color: AppAccentColor) {
        _accentColor.value = color
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleAiSearchMode() {
        _isAiSearchMode.value = !_isAiSearchMode.value
    }

    fun openFullscreenPhoto(photo: PhotoEntity) {
        _fullscreenPhoto.value = photo
    }

    fun closeFullscreenPhoto() {
        _fullscreenPhoto.value = null
    }

    fun openEditor(photo: PhotoEntity) {
        _photoForEdit.value = photo
    }

    fun closeEditor() {
        _photoForEdit.value = null
    }

    fun openInfo(photo: PhotoEntity) {
        _photoForInfo.value = photo
    }

    fun closeInfo() {
        _photoForInfo.value = null
    }

    fun openStoryMemory(title: String) {
        _activeStoryMemory.value = title
    }

    fun closeStoryMemory() {
        _activeStoryMemory.value = null
    }

    fun toggleFavorite(photo: PhotoEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(photo.id, !photo.isFavorite)
            _fullscreenPhoto.value?.let { current ->
                if (current.id == photo.id) {
                    _fullscreenPhoto.value = current.copy(isFavorite = !current.isFavorite)
                }
            }
        }
    }

    fun hidePhoto(context: Context, photo: PhotoEntity) {
        viewModelScope.launch {
            repository.hidePhotoToEncryptedVault(context, photo)
            if (_fullscreenPhoto.value?.id == photo.id) {
                closeFullscreenPhoto()
            }
        }
    }

    fun unhidePhoto(context: Context, photo: PhotoEntity) {
        viewModelScope.launch {
            repository.unhidePhotoFromEncryptedVault(context, photo)
        }
    }

    fun moveToTrash(photo: PhotoEntity) {
        viewModelScope.launch {
            repository.moveToTrash(photo.id)
            if (_fullscreenPhoto.value?.id == photo.id) {
                closeFullscreenPhoto()
            }
        }
    }

    fun restoreFromTrash(photo: PhotoEntity) {
        viewModelScope.launch {
            repository.restoreFromTrash(photo.id)
        }
    }

    fun deletePermanently(photo: PhotoEntity) {
        viewModelScope.launch {
            repository.deletePermanently(photo.id)
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            repository.emptyTrash()
        }
    }

    fun openHiddenVault() {
        _showHiddenVault.value = true
    }

    fun closeHiddenVault() {
        _showHiddenVault.value = false
        _isVaultUnlocked.value = false
    }

    fun unlockVaultWithPin(pin: String): Boolean {
        if (pin == "1234" || pin.length == 4) {
            _isVaultUnlocked.value = true
            return true
        }
        return false
    }

    fun unlockVaultWithBiometrics() {
        _isVaultUnlocked.value = true
    }

    fun openRecycleBin() {
        _showRecycleBin.value = true
    }

    fun closeRecycleBin() {
        _showRecycleBin.value = false
    }

    fun openAiTools() {
        _showAiToolsScreen.value = true
    }

    fun closeAiTools() {
        _showAiToolsScreen.value = false
        _selectedAiScan.value = null
    }

    fun runAiScan(context: Context, scanType: AiScanType) {
        _selectedAiScan.value = scanType
        viewModelScope.launch {
            repository.runAiToolsScanOnLibrary(context)
        }
    }

    fun toggleNotificationSheet() {
        _showNotificationSheet.value = !_showNotificationSheet.value
    }

    fun saveEditedPhoto(editedPhoto: PhotoEntity) {
        viewModelScope.launch {
            repository.updatePhoto(editedPhoto)
            _fullscreenPhoto.value = editedPhoto
            closeEditor()
        }
    }
}
