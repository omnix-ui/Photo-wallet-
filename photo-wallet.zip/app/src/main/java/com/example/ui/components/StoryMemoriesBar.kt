package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

data class MemoryStoryItem(
    val title: String,
    val subtitle: String,
    val coverUrl: String
)

@Composable
fun StoryMemoriesBar(
    onStoryClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val stories = listOf(
        MemoryStoryItem("Today", "5 New Photos", "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&q=80"),
        MemoryStoryItem("Last Week", "Kyoto Trip", "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800&q=80"),
        MemoryStoryItem("This Day Last Year", "2025 Memories", "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&q=80"),
        MemoryStoryItem("Summer Vacation", "Emerald Bay", "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&q=80"),
        MemoryStoryItem("Birthday Celebration", "24 Photos", "https://images.unsplash.com/photo-1519741497674-611481863552?w=800&q=80"),
        MemoryStoryItem("Friends & Family", "Alex & Sophia", "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=800&q=80")
    )

    Column(modifier = modifier) {
        Text(
            text = "Memories",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.testTag("story_memories_row")
        ) {
            items(stories) { story ->
                Box(
                    modifier = Modifier
                        .width(115.dp)
                        .height(150.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .border(
                            2.dp,
                            Brush.linearGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.tertiary
                                )
                            ),
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { onStoryClick(story.title) }
                        .testTag("story_${story.title.lowercase().replace(" ", "_")}")
                ) {
                    AsyncImage(
                        model = story.coverUrl,
                        contentDescription = story.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Soft Gradient Overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.8f)
                                    )
                                )
                            )
                    )

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = story.title,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = story.subtitle,
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Normal,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
