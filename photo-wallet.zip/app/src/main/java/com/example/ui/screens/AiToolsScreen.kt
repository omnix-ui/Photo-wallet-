package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.CopyAll
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.ImageSearch
import androidx.compose.material.icons.filled.PhotoSizeSelectLarge
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PhotoEntity
import com.example.ui.AiScanType
import com.example.ui.components.PhotoGrid

data class AiToolItem(
    val scanType: AiScanType,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val badgeText: String
)

@Composable
fun AiToolsScreen(
    selectedScan: AiScanType?,
    blurryPhotos: List<PhotoEntity>,
    duplicatePhotos: List<PhotoEntity>,
    faceGroupPhotos: List<PhotoEntity>,
    allPhotos: List<PhotoEntity>,
    gridColumns: Int,
    onRunScan: (AiScanType) -> Unit,
    onBackClick: () -> Unit,
    onPhotoClick: (PhotoEntity) -> Unit,
    onCleanScanItems: (List<PhotoEntity>) -> Unit,
    modifier: Modifier = Modifier
) {
    val aiTools = listOf(
        AiToolItem(AiScanType.SIMILAR, "Find Similar Photos", "Clusters burst & similar angle shots", Icons.Default.ImageSearch, "2 Groups"),
        AiToolItem(AiScanType.BLURRY, "Detect Blurry Photos", "Identifies out-of-focus & shaky photos", Icons.Default.BlurOn, "${blurryPhotos.size} Detected"),
        AiToolItem(AiScanType.DUPLICATE, "Duplicate Cleaner", "Detects exact duplicate photos to free storage", Icons.Default.CopyAll, "${duplicatePhotos.size} Found"),
        AiToolItem(AiScanType.SCREENSHOT, "Screenshot Cleaner", "Organizes chat & receipt screenshots", Icons.Default.Smartphone, "5 Receipts"),
        AiToolItem(AiScanType.LARGE_FILES, "Large File Finder", "Finds heavy 4K videos & RAW photos", Icons.Default.PhotoSizeSelectLarge, "3 Large Videos"),
        AiToolItem(AiScanType.FACE_GROUPING, "Face Grouping", "Categorizes photos by people's faces", Icons.Default.Face, "Alex, Sophia, Mom"),
        AiToolItem(AiScanType.MEMORIES, "Smart Memories Generator", "Auto-compiles story collages with music", Icons.Default.Psychology, "3 New Stories"),
        AiToolItem(AiScanType.AUTO_ALBUMS, "AI Auto Albums", "Auto-groups photos by events & locations", Icons.Default.FolderSpecial, "Kyoto, Beach")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick, modifier = Modifier.testTag("btn_ai_back")) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = "AI Gallery Tools",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }

        // AI Tools Cards Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(1),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 100.dp),
            modifier = Modifier.testTag("ai_tools_grid")
        ) {
            items(aiTools) { tool ->
                AiToolCard(
                    tool = tool,
                    onClick = { onRunScan(tool.scanType) }
                )
            }
        }
    }

    // AI Scan Results Modal
    if (selectedScan != null) {
        val (scanTitle, scanPhotos) = when (selectedScan) {
            AiScanType.BLURRY -> Pair("Blurry Photos Scan", blurryPhotos)
            AiScanType.DUPLICATE -> Pair("Duplicate Photos Scan", duplicatePhotos)
            AiScanType.FACE_GROUPING -> Pair("Face Grouping Scan", faceGroupPhotos)
            else -> Pair("AI Scan Results", allPhotos.take(6))
        }

        AlertDialog(
            onDismissRequest = { onRunScan(selectedScan) },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(text = scanTitle, modifier = Modifier.padding(start = 8.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Found ${scanPhotos.size} items matching AI criteria.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Box(modifier = Modifier.height(280.dp)) {
                        PhotoGrid(
                            photos = scanPhotos,
                            columns = 2,
                            onPhotoClick = onPhotoClick
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCleanScanItems(scanPhotos)
                    },
                    modifier = Modifier.testTag("btn_clean_ai_results")
                ) {
                    Text("Clean Selected (${scanPhotos.size})")
                }
            },
            dismissButton = {
                TextButton(onClick = { onRunScan(selectedScan) }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
fun AiToolCard(
    tool: AiToolItem,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.12f), RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(16.dp)
            .testTag("ai_card_${tool.scanType.name.lowercase()}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = tool.title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 14.dp)
            ) {
                Text(
                    text = tool.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = tool.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = tool.badgeText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
