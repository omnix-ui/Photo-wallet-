package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.PhotoEntity

data class AlbumCardData(
    val name: String,
    val count: Int,
    val coverUrl: String,
    val isSpecial: Boolean = false,
    val isVault: Boolean = false,
    val isTrash: Boolean = false,
    val isAi: Boolean = false
)

@Composable
fun AlbumsScreen(
    allPhotos: List<PhotoEntity> = emptyList(),
    hiddenCount: Int = 0,
    trashCount: Int = 0,
    onAlbumClick: (String) -> Unit,
    onOpenHiddenVault: () -> Unit,
    onOpenRecycleBin: () -> Unit,
    onOpenAiTools: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showCreateAlbumDialog by remember { mutableStateOf(false) }
    var newAlbumName by remember { mutableStateOf("") }
    var customAlbums by remember { mutableStateOf(listOf<String>()) }

    val photoAlbumsMap = remember(allPhotos) {
        allPhotos.groupBy { it.album }
    }

    // Default system buckets
    val defaultBucketNames = listOf("Camera", "Selfies", "Screenshots", "Downloads", "WhatsApp", "Instagram")
    val allBucketNames = (defaultBucketNames + photoAlbumsMap.keys + customAlbums).distinct()

    val dynamicAlbums = allBucketNames.map { name ->
        val photosInAlbum = photoAlbumsMap[name] ?: emptyList()
        AlbumCardData(
            name = name,
            count = photosInAlbum.size,
            coverUrl = photosInAlbum.firstOrNull()?.url ?: ""
        )
    }

    val specialAlbums = listOf(
        AlbumCardData("AI Tools Hub", allPhotos.size, allPhotos.firstOrNull()?.url ?: "", isSpecial = true, isAi = true),
        AlbumCardData("Hidden Vault", hiddenCount, "", isSpecial = true, isVault = true),
        AlbumCardData("Recycle Bin", trashCount, "", isSpecial = true, isTrash = true)
    )

    val allAlbums = dynamicAlbums + specialAlbums

    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        // Title Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Albums",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            // New Album Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .clickable { showCreateAlbumDialog = true }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("btn_create_album"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Album",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "New Album",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Albums Cards Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 100.dp),
            modifier = Modifier.testTag("albums_grid")
        ) {
            items(allAlbums) { album ->
                AlbumCard(
                    album = album,
                    onClick = {
                        when {
                            album.isVault -> onOpenHiddenVault()
                            album.isTrash -> onOpenRecycleBin()
                            album.isAi -> onOpenAiTools()
                            else -> onAlbumClick(album.name)
                        }
                    }
                )
            }
        }
    }

    // Create Album Dialog
    if (showCreateAlbumDialog) {
        AlertDialog(
            onDismissRequest = { showCreateAlbumDialog = false },
            title = { Text("Create New Album") },
            text = {
                OutlinedTextField(
                    value = newAlbumName,
                    onValueChange = { newAlbumName = it },
                    label = { Text("Album Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("input_album_name")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newAlbumName.isNotBlank()) {
                            customAlbums = customAlbums + newAlbumName.trim()
                            newAlbumName = ""
                            showCreateAlbumDialog = false
                        }
                    },
                    modifier = Modifier.testTag("btn_confirm_create_album")
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateAlbumDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AlbumCard(
    album: AlbumCardData,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.85f)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
                RoundedCornerShape(20.dp)
            )
            .clickable { onClick() }
            .testTag("album_card_${album.name.lowercase().replace(" ", "_")}")
    ) {
        AsyncImage(
            model = album.coverUrl,
            contentDescription = album.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Glass Overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = if (album.isSpecial) 0.55f else 0.35f))
        )

        // Special Badge
        if (album.isVault || album.isTrash || album.isAi) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(6.dp)
            ) {
                Icon(
                    imageVector = when {
                        album.isVault -> Icons.Default.Lock
                        album.isTrash -> Icons.Default.DeleteSweep
                        else -> Icons.Default.AutoAwesome
                    },
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Details Footer
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp)
        ) {
            Text(
                text = album.name,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = "${album.count} items",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal
            )
        }
    }
}
