package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PhotoEntity
import com.example.ui.components.CategoryChips
import com.example.ui.components.GlassmorphicContainer
import com.example.ui.components.PhotoGrid
import com.example.ui.components.StoryMemoriesBar

@Composable
fun HomeScreen(
    photos: List<PhotoEntity>,
    selectedCategory: String,
    gridColumns: Int,
    onCategorySelected: (String) -> Unit,
    onGridColumnsChanged: (Int) -> Unit,
    onPhotoClick: (PhotoEntity) -> Unit,
    onSearchClick: () -> Unit,
    onAiSearchClick: () -> Unit,
    onAiToolsClick: () -> Unit,
    onStoryClick: (String) -> Unit,
    onNotificationClick: () -> Unit,
    onOpenHiddenVault: () -> Unit,
    onOpenRecycleBin: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showOverflowMenu by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        // Top Glass Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            GlassmorphicContainer(
                cornerRadius = 24.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // App Title
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        Text(
                            text = "Photo Wallet",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("app_title")
                        )
                    }

                    // Action Icons
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Search Button
                        IconButton(
                            onClick = onSearchClick,
                            modifier = Modifier.testTag("btn_search")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // AI Search Button (Visually Distinct Sparkle Chip)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer)
                                .clickable { onAiSearchClick() }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("btn_ai_search"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI Search",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "AI",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        // Grid Columns Switcher Toggle
                        IconButton(
                            onClick = {
                                val nextCols = if (gridColumns == 2) 3 else if (gridColumns == 3) 4 else 2
                                onGridColumnsChanged(nextCols)
                            },
                            modifier = Modifier.testTag("btn_grid_columns")
                        ) {
                            Icon(
                                imageVector = Icons.Default.GridView,
                                contentDescription = "Grid Columns",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Notifications Bell with Badge
                        Box {
                            IconButton(
                                onClick = onNotificationClick,
                                modifier = Modifier.testTag("btn_notification")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                                    .align(Alignment.TopEnd)
                                    .padding(top = 8.dp, end = 8.dp)
                            )
                        }

                        // Overflow Menu
                        Box {
                            IconButton(
                                onClick = { showOverflowMenu = true },
                                modifier = Modifier.testTag("btn_overflow_menu")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "Menu",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            DropdownMenu(
                                expanded = showOverflowMenu,
                                onDismissRequest = { showOverflowMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("AI Tools Hub") },
                                    onClick = {
                                        showOverflowMenu = false
                                        onAiToolsClick()
                                    },
                                    leadingIcon = {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Hidden Vault") },
                                    onClick = {
                                        showOverflowMenu = false
                                        onOpenHiddenVault()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Recycle Bin") },
                                    onClick = {
                                        showOverflowMenu = false
                                        onOpenRecycleBin()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Horizontal Category Chips
        CategoryChips(
            selectedCategory = selectedCategory,
            onCategorySelected = onCategorySelected,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        // Story Memories Horizontal Bar
        StoryMemoriesBar(
            photos = photos,
            onStoryClick = onStoryClick,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        // Photos Grid Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$selectedCategory (${photos.size})",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "${gridColumns} Columns",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.clickable {
                    val nextCols = if (gridColumns == 2) 3 else if (gridColumns == 3) 4 else 2
                    onGridColumnsChanged(nextCols)
                }
            )
        }

        // Photo Grid
        PhotoGrid(
            photos = photos,
            columns = gridColumns,
            onPhotoClick = onPhotoClick,
            modifier = Modifier.weight(1f)
        )
    }
}
