package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.PhotoEntity

@Composable
fun PhotoEditorDialog(
    photo: PhotoEntity,
    onDismiss: () -> Unit,
    onSave: (PhotoEntity) -> Unit
) {
    var editedTitle by remember { mutableStateOf(photo.title) }
    var rotationAngle by remember { mutableFloatStateOf(0f) }
    var selectedFilter by remember { mutableStateOf("Original") }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(1f) }

    val filterList = listOf("Original", "Vintage", "Warm Sunset", "Cool Cyber", "Vivid Pop", "Monochrome")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Top Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("btn_close_editor")) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel")
                    }
                    Text(
                        text = "Photo Editor",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    IconButton(
                        onClick = {
                            val updated = photo.copy(title = editedTitle.ifBlank { photo.title })
                            onSave(updated)
                        },
                        modifier = Modifier.testTag("btn_save_edit")
                    ) {
                        Icon(Icons.Default.Check, contentDescription = "Save", tint = MaterialTheme.colorScheme.primary)
                    }
                }

                // Image Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black),
                    contentAlignment = Alignment.Center
                ) {
                    val colorMatrix = remember(selectedFilter, brightness, contrast) {
                        ColorMatrix().apply {
                            setToContrast(contrast)
                            when (selectedFilter) {
                                "Vintage" -> {
                                    set(0, 0, 1.2f)
                                    set(1, 1, 0.9f)
                                    set(2, 2, 0.7f)
                                }
                                "Warm Sunset" -> {
                                    set(0, 0, 1.3f)
                                    set(1, 1, 1.1f)
                                }
                                "Cool Cyber" -> {
                                    set(0, 0, 0.8f)
                                    set(2, 2, 1.3f)
                                }
                                "Monochrome" -> setToSaturation(0f)
                                "Vivid Pop" -> setToSaturation(1.6f)
                            }
                        }
                    }

                    AsyncImage(
                        model = photo.url,
                        contentDescription = "Edit preview",
                        contentScale = ContentScale.Fit,
                        colorFilter = ColorFilter.colorMatrix(colorMatrix),
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(rotationAngle)
                    )
                }

                // Scrollable Controls Panel
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Title Editor
                    OutlinedTextField(
                        value = editedTitle,
                        onValueChange = { editedTitle = it },
                        label = { Text("Photo Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_edit_title")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Tool Bar (Rotate)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Rotate Canvas",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        IconButton(
                            onClick = { rotationAngle = (rotationAngle + 90f) % 360f },
                            modifier = Modifier.testTag("btn_rotate_photo")
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = "Rotate")
                        }
                    }

                    // Filters Selector
                    Text(
                        text = "Presets & Filters",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(vertical = 4.dp).testTag("filters_row")
                    ) {
                        items(filterList) { filterName ->
                            val isSelected = selectedFilter == filterName
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { selectedFilter = filterName }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                                    .testTag("filter_${filterName.lowercase().replace(" ", "_")}")
                            ) {
                                Text(
                                    text = filterName,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Contrast Slider
                    Text(
                        text = "Contrast: ${(contrast * 100).toInt()}%",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Slider(
                        value = contrast,
                        onValueChange = { contrast = it },
                        valueRange = 0.5f..2.0f,
                        modifier = Modifier.testTag("slider_contrast")
                    )
                }
            }
        }
    }
}

private fun ColorMatrix.setToContrast(contrast: Float) {
    val scale = contrast
    val translate = (-0.5f * scale + 0.5f) * 255f
    set(0, 0, scale)
    set(1, 1, scale)
    set(2, 2, scale)
    set(0, 4, translate)
    set(1, 4, translate)
    set(2, 4, translate)
}
