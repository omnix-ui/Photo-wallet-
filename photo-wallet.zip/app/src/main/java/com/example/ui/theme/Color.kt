package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Accent Color options
val AccentIndigo = Color(0xFF6366F1)
val AccentEmerald = Color(0xFF10B981)
val AccentRose = Color(0xFFF43F5E)
val AccentSunset = Color(0xFFF97316)
val AccentAmber = Color(0xFFF59E0B)
val AccentOcean = Color(0xFF06B6D4)

// Light Palette Base
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightOnSurfaceVariant = Color(0xFF64748B)

// Dark Palette Base
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)

enum class AppAccentColor(val color: Color, val displayName: String) {
    INDIGO(AccentIndigo, "Indigo"),
    EMERALD(AccentEmerald, "Emerald"),
    ROSE(AccentRose, "Rose"),
    SUNSET(AccentSunset, "Sunset"),
    AMBER(AccentAmber, "Amber"),
    OCEAN(AccentOcean, "Ocean")
}
